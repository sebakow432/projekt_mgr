import React, { useState } from 'react';
import Login from './Login';
import MainApp from './MainApp';
import Footer from './Footer';

function App() {
  const [user, setUser] = useState(null);

  const handleLogin = (userData) => {
    setUser(userData);
  };

  const handleLogout = () => {
    setUser(null);
  };

  return (
    <div>
      {!user ? (
        <Login onLogin={handleLogin} />
      ) : (
        <MainApp user={user} onLogout={handleLogout} />
      )}
      <Footer />
    </div>
  );
}

export default App;
