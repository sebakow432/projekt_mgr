function Footer() {
    return (
      <footer className="app-footer">
        <p>© {new Date().getFullYear()} ZabiegiApp. Wszelkie prawa zastrzeżone.</p>
      </footer>
    );
  }
  
export default Footer;
  