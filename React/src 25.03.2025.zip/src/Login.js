import React, { useState } from 'react';
import './Login.scss';

function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    // Prosta walidacja przed wysłaniem żądania
    if (!username.trim() || !password.trim()) {
      setError('Wprowadź login i hasło');
      return;
    }

    fetch(`http://localhost:3000/users?username=${username}&password=${password}`)
      .then(res => res.json())
      .then(users => {
        if (users.length > 0) {
          onLogin(users[0]);
        } else {
          setError('Błędny login lub hasło');
        }
      })
      .catch(() => setError('Błąd serwera'));
  };

  // Obsługa Entera
  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  return (
    <div className="login-container">
      <h2 className="login-title">Logowanie</h2>
      <div className="login-form">
        <label htmlFor="username">Login</label>
        <input
          id="username"
          type="text"
          value={username}
          onChange={e => setUsername(e.target.value)}
          onKeyDown={handleKeyDown}
        />

        <label htmlFor="password">Hasło</label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={e => setPassword(e.target.value)}
          onKeyDown={handleKeyDown}
        />

        <button onClick={handleLogin}>Zaloguj się</button>

        {error && <p className="error-message">{error}</p>}
      </div>
    </div>
  );
}

export default Login;
  