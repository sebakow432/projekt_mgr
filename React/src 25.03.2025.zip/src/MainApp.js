import React from 'react';

function MainApp({ user, onLogout }) {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Witaj, {user.name}!</h1>
      <p>Twoja rola: {user.role}</p>

      {/* Tu będą dalsze kafelki, nawigacja itp. */}
      
      <button onClick={onLogout}>Wyloguj się</button>
    </div>
  );
}

export default MainApp;
  